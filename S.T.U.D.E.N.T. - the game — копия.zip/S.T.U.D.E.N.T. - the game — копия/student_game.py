from threading import Lock


class SingletonMeta(type):
    _instances = {}
    _lock: Lock = Lock()

    def __call__(cls, *args, **kwargs):
        with cls._lock:
            if cls not in cls._instances or args or kwargs:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance
        return cls._instances[cls]


class TextQuest(metaclass=SingletonMeta):
    def __init__(self, new=False):
        self._horizontal_position = 0
        self._vertical_position = 1
        self.moves = -1
        self._rooms_map = [[0 for y in range(2)] for x in range(3)]
        self._rooms_map[self._horizontal_position][self._vertical_position] = 1
        self._rooms_desc = (
            ("В помещении много полок с разными документами о студентах, это явно деканат.",
             "В помещении стоят столы, на каждом из которых стоят мониторы, подключённые к компьютерам , это явно компьютерная аудитория."),
            ("Это коридор, в северной стороне стоят турникеты, а за ними выход.",
             "В помещении стоит большой диван, много еды, чай и тумба с телевизором, это явно кабинет Элисо Отаровны."),
            ("В помещении стоят большие сервера и свисают кучи проводов, это явно серверная.",
             "В комнате стоит компьютер, стелаж с книгами, это явно рабочий кабинет.")
        )

    def end_text(self):
        return "Вы выходите на улицу и закуриваете долгожданную сигарету. " \
               "Скоро пары кончатся и можно отправляться домой играть в доту. Конец."

    def check_visited(self):
        if self._rooms_map[self._horizontal_position][self._vertical_position] == 1:
            return " Вам кажется, что вы здесь уже были."
        else:
            self._rooms_map[self._horizontal_position][self._vertical_position] = 1
            return ""

    def get_room_decs(self):
        return self._rooms_desc[self._horizontal_position][self._vertical_position]

    def move(self, direction):
        if direction == 0 and self._horizontal_position == 1 and self._vertical_position == 0:
            return 3
        if (direction == 0 and self._vertical_position == 0) or \
                (direction == 1 and self._horizontal_position == 2) or \
                (direction == 2 and self._vertical_position == 1) or \
                (direction == 3 and self._horizontal_position == 0):
            return 2
        if direction == 0:
            self._vertical_position -= 1
        elif direction == 1:
            self._horizontal_position += 1
        elif direction == 2:
            self._vertical_position += 1
        elif direction == 3:
            self._horizontal_position -= 1
        self.moves += 1
        return 1

    def wrong_move_text(self):
        return "Вы упираетесь в стену, дальше идти нельзя."

    def start_text(self):
        return "Сегодняшняя ночь явно не удалась, Вы просыпаетесь сидя за столом в аудитории " \
               "от прозвеневшего звонка на перемену. " \
               "У вас жутко болит голова, и вам " \
               "очень сильно хочется курить, благо в кармане есть полупустая пачка сигарет " \
               "и зажигалка, осталось найти выход и осуществить свое сокровенное желание."
